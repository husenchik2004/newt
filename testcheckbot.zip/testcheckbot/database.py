import sqlite3
from datetime import datetime
from typing import Optional

class DB:
    def __init__(self, path):
        # Подключение к базе данных
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self._create_tables()

    def _create_tables(self):
        """Создаёт таблицы при первом запуске"""
        cur = self.conn.cursor()
        # Таблица с учениками
        cur.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER,
            chat_id INTEGER,
            raw_text TEXT,
            name TEXT,
            branch TEXT,
            language TEXT,
            class_name TEXT,
            phone TEXT,
            created_at TEXT
        )
        """)
        # Таблица со статусами шагов
        cur.execute("""
        CREATE TABLE IF NOT EXISTS steps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            step TEXT,
            user_id INTEGER,
            username TEXT,
            done_at TEXT,
            UNIQUE(student_id, step)
        )
        """)
        self.conn.commit()

    def add_student(self, message_id, chat_id, raw_text, name=None, branch=None, language=None, class_name=None, phone=None):
        """Добавляет нового ученика"""
        cur = self.conn.cursor()
        now = datetime.utcnow().isoformat()
        cur.execute("""
        INSERT INTO students (message_id, chat_id, raw_text, name, branch, language, class_name, phone, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (message_id, chat_id, raw_text, name, branch, language, class_name, phone, now))
        self.conn.commit()
        return cur.lastrowid

    def add_step(self, student_id, step, user_id, username):
        """Добавляет отметку о выполнении шага"""
        cur = self.conn.cursor()
        now = datetime.utcnow().isoformat()
        try:
            cur.execute("""
            INSERT INTO steps (student_id, step, user_id, username, done_at)
            VALUES (?, ?, ?, ?, ?)
            """, (student_id, step, user_id, username, now))
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def get_steps(self, student_id):
        """Возвращает список шагов по ученику"""
        cur = self.conn.cursor()
        cur.execute("SELECT step, user_id, username, done_at FROM steps WHERE student_id=?", (student_id,))
        return cur.fetchall()

    def get_student(self, student_id):
        """Возвращает информацию об ученике"""
        cur = self.conn.cursor()
        cur.execute("""
        SELECT id, message_id, chat_id, raw_text, name, branch, language, class_name, phone, created_at
        FROM students WHERE id=?
        """, (student_id,))
        return cur.fetchone()

    def get_pending_for_reminder(self, older_than_iso):
        """Ищет учеников, у которых не отмечены все 3 шага спустя 24 часа"""
        cur = self.conn.cursor()
        cur.execute("""
        SELECT s.id, s.name, s.branch, s.language, s.created_at
        FROM students s
        LEFT JOIN steps st ON s.id = st.student_id
        GROUP BY s.id
        HAVING COUNT(st.id) < 3 AND s.created_at <= ?
        """, (older_than_iso,))
        return cur.fetchall()

    def list_students_since(self, since_iso):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM students WHERE created_at >= ?", (since_iso,))
        return cur.fetchall()
