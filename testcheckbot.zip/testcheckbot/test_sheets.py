from google_sheets import SheetsClient

SPREADSHEET_ID = "1NVrwno5oYmBcCqRXYnJyXEqiyMKlsvZ5u6tUl5glHOg"
GOOGLE_CREDS_JSON = "/Users/user/Desktop/testcheckbot/service_account.json"

sheets = SheetsClient(GOOGLE_CREDS_JSON, SPREADSHEET_ID)
sheets.append_row(["Тест Ученик", "Ракат", "9", "РУС", "+998950161121", "✅", "✅", "✅", "NewtonBot", "Готов", "2025-10-16"])
print("✅ Тестовая запись добавлена в таблицу!")