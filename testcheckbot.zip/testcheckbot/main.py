import asyncio
import re
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
import pytz

# ===============================
# 🔧 КОНФИГ И ИНИЦИАЛИЗАЦИЯ
# ===============================
from config import (
    BOT_TOKEN,
    SOURCE_CHAT_ID,
    TARGET_CHAT_ID,
    REPORT_CHAT_ID,
    GOOGLE_CREDS_JSON,
    SPREADSHEET_ID,
    DATABASE_PATH,
    ADMINS
)
from database import DB
from google_sheets import SheetsClient

print("🟢 Бот загружается...")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()
scheduler = AsyncIOScheduler()
db = DB(DATABASE_PATH)
sheets = SheetsClient(GOOGLE_CREDS_JSON, SPREADSHEET_ID)
sheets.prepare_headers_if_empty()

STEPS = ["placement", "group", "sms"]

# Настройки
TEST_MODE = False
TEST_DURATION = 10                # 10 сек
PROD_DURATION = 24 * 3600         # 24 часа
running_timers = {}

# ===============================
# 🧱 ВСПОМОГАТЕЛЬНЫЕ
# ===============================
def build_keyboard(student_id, done_steps=None):
    if done_steps is None:
        done_steps = set()
    labels = {
        "placement": "Звонок-знакомство сделан",
        "group": "Группа подтверждена",
        "sms": "Напомни про урок"
    }
    def txt(step):
        return f"✅ {labels[step]}" if step in done_steps else f"🟡 {labels[step]}"
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=txt("placement"), callback_data=f"placement:{student_id}")],
        [InlineKeyboardButton(text=txt("group"), callback_data=f"group:{student_id}")],
        [InlineKeyboardButton(text=txt("sms"), callback_data=f"sms:{student_id}")]
    ])

def parse_student_info(text: str):
    def find(pattern):
        m = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
        return m.group(1).strip() if m else None
    data = {
        "branch": find(r"Филиал:\s*(.+)"),
        "child_name": find(r"Имя\s*ребёнка:\s*(.+)"),
        "class_name": find(r"Класс:\s*(.+)"),
        "language": find(r"Язык:\s*(.+)"),
        "phone": find(r"Номер:\s*(\+?\d[\d\s-]+)")
    }
    for k, v in data.items():
        if isinstance(v, str):
            data[k] = v.replace("–", "-").replace("—", "-").strip()
    return data

def is_admin(user_id: int) -> bool:
    return user_id in ADMINS

# ===============================
# ⏳ ОБРАТНЫЙ ОТСЧЁТ
# ===============================
async def countdown_and_notify(student_id: int, chat_id: int, message_id: int,
                               student_name: str, base_text: str, kb: InlineKeyboardMarkup,
                               duration_seconds: int):
    print(f"🕒 Таймер запущен: {student_name} ({duration_seconds}s)")
    remaining = int(duration_seconds)
    update_interval = 1 if remaining <= 60 else 60
    try:
        while remaining > 0:
            hrs, rem = divmod(remaining, 3600)
            mins, secs = divmod(rem, 60)
            time_str = f"{hrs:02d}:{mins:02d}:{secs:02d}" if hrs else f"{mins:02d}:{secs:02d}"
            new_text = f"{base_text}\n\n⏳ Осталось времени до подтверждения: *{time_str}*"
            try:
                await bot.edit_message_text(new_text, chat_id, message_id, reply_markup=kb, parse_mode="Markdown")
            except Exception:
                pass
            await asyncio.sleep(update_interval)
            remaining -= update_interval

        await asyncio.sleep(2)
        await bot.send_message(
            chat_id=chat_id,
            text=f"⚠️ Время подтверждения истекло для ученика *{student_name}*.",
            parse_mode="Markdown",
            reply_to_message_id=message_id
        )
        print(f"🔔 Таймер истёк — {student_name}")

    except asyncio.CancelledError:
        print(f"⏹ Таймер отменён: {student_name}")
    finally:
        running_timers.pop(student_id, None)

        # ==========================================
# 📊 КОМАНДЫ ОТЧЁТОВ
# ==========================================
from datetime import datetime, timedelta
from aiogram.filters import Command

# 🧠 Хелпер: формат ISO с секундами
def iso_bounds(start: datetime, end: datetime) -> tuple[str, str]:
    start_iso = start.replace(microsecond=0).isoformat()
    end_iso = end.replace(microsecond=0).isoformat()
    return start_iso, end_iso


# 🧾 Генератор текста отчёта
async def generate_report_text(title: str, start: datetime, end: datetime):
    start_iso, end_iso = iso_bounds(start, end)
    stats = await compute_stats_between(start_iso, end_iso)

    t = stats["total"]
    p = stats["placement_done"]
    g = stats["group_done"]
    s = stats["sms_done"]
    f = stats["fully_done"]

    return (
        f"📊 *{title}*\n"
        f"Период: {start.strftime('%d.%m.%Y %H:%M')} — {end.strftime('%d.%m.%Y %H:%M')}\n\n"
        f"— Новых заявок: {t}\n"
        f"— Звонок-знакомство: {p} ✅ / {t - p} ❌\n"
        f"— Группа подтверждена: {g} ✅ / {t - g} ❌\n"
        f"— Напомнить про урок : {s} ✅ / {t - s} ❌\n"
        f"— Полностью готовы к учебе: {f} ✅"
    )


# ======================================
# 📅 ДНЕВНОЙ ОТЧЁТ (с 00:00 до 23:59 сегодня)
# ======================================
@dp.message(Command("report_today"))

async def report_today(message: types.Message):
    now = datetime.utcnow()
    start = datetime(now.year, now.month, now.day, 0, 0, 0)
    end = start + timedelta(days=1) - timedelta(seconds=1)
    text = await generate_report_text("Отчёт за сегодня", start, end)
    await message.answer(text, parse_mode="Markdown")


# ======================================
# 📅 ВЧЕРАШНИЙ ОТЧЁТ (с 00:00 до 23:59 вчера)
# ======================================
@dp.message(Command("report_yesterday"))

async def report_yesterday(message: types.Message):
    now = datetime.utcnow()
    start = datetime(now.year, now.month, now.day, 0, 0, 0) - timedelta(days=1)
    end = start + timedelta(days=1) - timedelta(seconds=1)
    text = await generate_report_text("Отчёт за вчера", start, end)
    await message.answer(text, parse_mode="Markdown")


# ======================================
# 📅 НЕДЕЛЬНЫЙ ОТЧЁТ (понедельник—воскресенье)
# ======================================
@dp.message(Command("report_week"))

async def report_week(message: types.Message):
    now = datetime.utcnow()
    start_of_week = now - timedelta(days=now.weekday())  # понедельник
    start = datetime(start_of_week.year, start_of_week.month, start_of_week.day, 0, 0, 0)
    end = start + timedelta(days=7) - timedelta(seconds=1)
    text = await generate_report_text("Отчёт за неделю", start, end)
    await message.answer(text, parse_mode="Markdown")


# ======================================
# 📅 МЕСЯЧНЫЙ ОТЧЁТ
# ======================================
@dp.message(Command("report_month"))

async def report_month(message: types.Message):
    now = datetime.utcnow()
    start = datetime(now.year, now.month, 1, 0, 0, 0)
    if now.month == 12:
        next_month = datetime(now.year + 1, 1, 1)
    else:
        next_month = datetime(now.year, now.month + 1, 1)
    end = next_month - timedelta(seconds=1)
    text = await generate_report_text("Отчёт за месяц", start, end)
    await message.answer(text, parse_mode="Markdown")


@dp.callback_query()
async def handle_callback(cq: types.CallbackQuery):
    if not cq.data or ":" not in cq.data:
        await cq.answer()
        return
    step, sid_str = cq.data.split(":", 1)
    try:
        sid = int(sid_str)
    except ValueError:
        await cq.answer("Ошибка ID")
        return

    user = cq.from_user
    username = user.username or user.full_name

    ok = db.add_step(sid, step, user.id, username)
    if not ok:
        await cq.answer("Уже отмечено", show_alert=True)
        return

    try:
        sheets.update_step_by_id(sid, step, username)
    except Exception as e:
        print("❌ Sheets update_step_by_id failed:", e)

    steps = db.get_steps(sid)
    done_steps = {r[0] for r in steps}
    new_kb = build_keyboard(sid, done_steps)
    try:
        await cq.message.edit_reply_markup(reply_markup=new_kb)
    except Exception as e:
        print("⚠️ edit_reply_markup failed:", e)

    await cq.answer(f"✅ Шаг '{step}' отмечен @{username}")

    if all(s in done_steps for s in STEPS):
        try:
            sheets.mark_ready_by_id(sid)
        except Exception as e:
            print("❌ mark_ready_by_id failed:", e)
        task = running_timers.pop(sid, None)
        if task and not task.done():
            task.cancel()
        await bot.send_message(
            cq.message.chat.id,
            f"✅ Ученик {cq.message.text.split('👶 Ученик: ')[1].splitlines()[0]} готов к старту!\n🌟 Newton Power 💛",
            reply_to_message_id=cq.message.message_id
        )

# ===============================
# 📊 ОТЧЁТЫ
# ===============================
def iso_from_dt(dt: datetime) -> str:
    return dt.replace(microsecond=0).isoformat()

def period_bounds_for_day_local(day: datetime):
    local_tz = pytz.timezone("Asia/Tashkent")
    start_local = local_tz.localize(datetime(day.year, day.month, day.day, 0, 0, 0))
    end_local = start_local + timedelta(days=1)
    return start_local.astimezone(pytz.UTC).isoformat(), end_local.astimezone(pytz.UTC).isoformat()

async def compute_stats_between(start_iso: str, end_iso: str):
    students = db.list_students_since(start_iso)
    total = placement_done = group_done = sms_done = fully_done = 0

    for s in students:
        created_at = None
        for item in reversed(s):
            if isinstance(item, str) and len(item) >= 10 and item[4] == "-":
                created_at = item
                break
        if not created_at or not (start_iso <= created_at < end_iso):
            continue

        total += 1
        sid = s[0]
        steps = db.get_steps(sid)
        done = {r[0] for r in steps}
        if "placement" in done:
            placement_done += 1
        if "group" in done:
            group_done += 1
        if "sms" in done:
            sms_done += 1
        if all(x in done for x in ["placement", "group", "sms"]):
            fully_done += 1

    print(f"📅 compute_stats_between: {start_iso[:10]} — {end_iso[:10]} | total={total}")
    return {
        "total": total,
        "placement_done": placement_done,
        "group_done": group_done,
        "sms_done": sms_done,
        "fully_done": fully_done
    }

def fmt_section(title: str, stats: dict) -> str:
    t = stats["total"]
    p = stats["placement_done"]
    g = stats["group_done"]
    s = stats["sms_done"]
    f = stats["fully_done"]
    return (
        f"\n*{title}*\n"
        f"— Новых заявок: {t}\n"
        f"— ☎️ Звонок-знакомство: {p} ✅ / {t - p} ❌\n"
        f"— 👥 Группа подтверждена: {g} ✅ / {t - g} ❌\n"
        f"— 💬 Напомнить про урок: {s} ✅ / {t - s} ❌\n"
        f"— 🌟 Полностью готовы: {f} ✅"
    )


# ===============================
# 💬 ХЭНДЛЕРЫ
# ===============================
@dp.message(Command("start"))
async def start_cmd(message: types.Message):
    await message.answer("✅ StartCheck бот запущен и готов работать!")
    
# ==========================================
# 📊 ОТЧЁТНЫЕ КОМАНДЫ
# ==========================================
import pytz
from datetime import datetime, timedelta

def get_tashkent_now():
    """Текущее время в часовом поясе Ташкента"""
    return datetime.now(pytz.timezone("Asia/Tashkent"))

def start_of_day(dt: datetime):
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)

def end_of_day(dt: datetime):
    return dt.replace(hour=23, minute=59, second=59, microsecond=999999)

# -------------------- /report_today --------------------
@dp.message(Command("report_today"))
async def report_today(message: types.Message):
    now = get_tashkent_now()
    start = start_of_day(now)
    end = end_of_day(now)
    await message.answer("📅 Формирую отчёт за *сегодня*...")
    text = await generate_report_for_period(start, end, f"Отчёт за сегодня ({now.strftime('%d.%m.%Y')})")
    await message.answer(text, parse_mode="Markdown")

# -------------------- /report_yesterday --------------------
@dp.message(Command("report_yesterday"))
async def report_yesterday(message: types.Message):
    now = get_tashkent_now()
    yesterday = now - timedelta(days=1)
    start = start_of_day(yesterday)
    end = end_of_day(yesterday)
    await message.answer("📆 Формирую отчёт за *вчера*...")
    text = await generate_report_for_period(start, end, f"Отчёт за вчера ({yesterday.strftime('%d.%m.%Y')})")
    await message.answer(text, parse_mode="Markdown")

# -------------------- /report_week --------------------
@dp.message(Command("report_week"))
async def report_week(message: types.Message):
    now = get_tashkent_now()
    start = start_of_day(now - timedelta(days=now.weekday()))  # понедельник
    end = end_of_day(start + timedelta(days=6))                # воскресенье
    await message.answer("📊 Формирую отчёт за *неделю*...")
    text = await generate_report_for_period(start, end, f"Отчёт за неделю ({start.strftime('%d.%m')}–{end.strftime('%d.%m')})")
    await message.answer(text, parse_mode="Markdown")

# -------------------- /report_month --------------------
@dp.message(Command("report_month"))
async def report_month(message: types.Message):
    now = get_tashkent_now()
    start = start_of_day(datetime(now.year, now.month, 1, tzinfo=now.tzinfo))
    if now.month == 12:
        next_month = datetime(now.year + 1, 1, 1, tzinfo=now.tzinfo)
    else:
        next_month = datetime(now.year, now.month + 1, 1, tzinfo=now.tzinfo)
    end = end_of_day(next_month - timedelta(days=1))

    await message.answer("🗓 Формирую отчёт за *месяц*...")
    text = await generate_report_for_period(start, end, f"Отчёт за месяц ({now.strftime('%B %Y')})")
    await message.answer(text, parse_mode="Markdown")

@dp.message()
async def catch_messages(message: types.Message):
    if message.chat.id != SOURCE_CHAT_ID:
        return

    raw = message.text or ""
    info = parse_student_info(raw)
    student_id = db.add_student(
        message.message_id, message.chat.id, raw,
        name=info.get("child_name"),
        branch=info.get("branch"),
        language=info.get("language"),
        class_name=info.get("class_name"),
        phone=info.get("phone")
    )

    try:
        sheets.append_student(
            sid=student_id,
            name=info.get("child_name") or "-",
            branch=info.get("branch") or "-",
            class_name=info.get("class_name") or "-",
            language=info.get("language") or "-",
            phone=info.get("phone") or "-"
        )
    except Exception as e:
        print("❌ Sheets append_student failed:", e)

    kb = build_keyboard(student_id)
    text = (
        f"📋 StartCheck:\n"
        f"👶 Ученик: {info.get('child_name') or '—'}\n"
        f"🏫 Филиал: {info.get('branch') or '—'}\n"
        f"📚 Класс: {info.get('class_name') or '—'}\n"
        f"🗣 Язык: {info.get('language') or '—'}\n"
        f"📞 Номер: {info.get('phone') or '—'}\n\n"
        f"Отметьте шаги по мере выполнения:"
    )

    sent = await bot.send_message(TARGET_CHAT_ID, text, reply_markup=kb)
    await message.reply("✅ Анкета добавлена в StartCheck.")

    duration = TEST_DURATION if TEST_MODE else PROD_DURATION
    task = asyncio.create_task(countdown_and_notify(
        student_id, sent.chat.id, sent.message_id,
        info.get("child_name") or f"student_{student_id}",
        text, kb, duration
    ))
    running_timers[student_id] = task

# ==========================================
# 📅 АВТОМАТИЧЕСКИЙ ОТЧЁТ С ПЛАНИРОВЩИКОМ
# ==========================================
import asyncio
import pytz
from datetime import datetime, timedelta
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.date import DateTrigger

# =================================================
# 🧭 Вспомогательная функция для границ дня
# =================================================
def period_bounds_for_day_local(day: datetime):
    """Возвращает ISO-границы дня по времени Ташкента."""
    start = datetime(day.year, day.month, day.day)
    end = start + timedelta(days=1)
    return start.isoformat(), end.isoformat()
# =================================================
# 📊 ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ ОТЧЁТА
# =================================================
from datetime import datetime, timedelta

async def compute_stats_between(start_iso: str, end_iso: str):
    """
    Подсчитывает количество учеников и отмеченные шаги
    между двумя временными границами (ISO-формат)
    """
    students = db.list_students_since(start_iso)
    total = placement_done = group_done = sms_done = fully_done = 0

    for s in students:
        created_at = None
        for item in s[::-1]:
            if isinstance(item, str) and len(item) >= 10 and item[4] == "-":
                created_at = item
                break
        if created_at and start_iso <= created_at < end_iso:
            total += 1
            sid = s[0]
            steps = db.get_steps(sid)
            done = {r[0] for r in steps}
            if "placement" in done:
                placement_done += 1
            if "group" in done:
                group_done += 1
            if "sms" in done:
                sms_done += 1
            if all(x in done for x in ["placement", "group", "sms"]):
                fully_done += 1

    return {
        "total": total,
        "placement_done": placement_done,
        "group_done": group_done,
        "sms_done": sms_done,
        "fully_done": fully_done,
    }


def fmt_section(title: str, stats: dict) -> str:
    """Форматирует текстовую секцию отчёта"""
    t = stats["total"]
    p = stats["placement_done"]
    g = stats["group_done"]
    s = stats["sms_done"]
    f = stats["fully_done"]
    return (
        f"\n*{title}*\n"
        f"— Новых заявок: {t}\n"
        f"— ☎️ Звонок-знакомство: {p} ✅ / {t - p} ❌\n"
        f"— 👥 Группа подтверждена: {g} ✅ / {t - g} ❌\n"
        f"— 💬 Напомнить про урок (SMS): {s} ✅ / {t - s} ❌\n"
        f"— 🌟 Полностью готовы: {f} ✅"
    )


async def generate_report_for_period(start: datetime, end: datetime, title: str):
    """Создаёт текст отчёта за указанный период"""
    stats = await compute_stats_between(start.isoformat(), end.isoformat())
    text = f"📊 *StartCheck — {title}*\n" + fmt_section(title, stats)
    return text


# =================================================
# 🕕 1. ФУНКЦИЯ ОТЧЁТА
# =================================================
async def send_daily_report_06():
    """Автоматическая отправка ежедневного отчёта за вчера."""
    print("🕕 Планировщик: запуск send_daily_report_06()")
    try:
        now_local = datetime.now(pytz.timezone("Asia/Tashkent"))
        yesterday = now_local - timedelta(days=1)
        start_iso, end_iso = period_bounds_for_day_local(yesterday)
        start = datetime.fromisoformat(start_iso)
        end = datetime.fromisoformat(end_iso)

        # ⚙️ Генерация текста отчёта
        text = await generate_report_for_period(
            start, end, f"Ежедневный отчёт за {yesterday.strftime('%d.%m.%Y')}"
        )

        # 📤 Отправка в группу отчётов
        await bot.send_message(REPORT_CHAT_ID, text, parse_mode="Markdown")
        print("✅ Ежедневный отчёт успешно отправлен.")
    except Exception as e:
        print("❌ Ошибка отправки отчёта:", e)


# =================================================
# 🧩 2. БЕЗОПАСНЫЙ ЗАПУСК async-задач
# =================================================
MAIN_LOOP = None  # глобальная ссылка на главный event loop

def safe_async_task(coro):
    """Безопасно запускает async-задачу из планировщика."""
    global MAIN_LOOP
    if MAIN_LOOP and not MAIN_LOOP.is_closed():
        asyncio.run_coroutine_threadsafe(coro, MAIN_LOOP)
    else:
        print("⚠️ Ошибка safe_async_task: event loop не найден или закрыт.")


# =================================================
# ⏰ 3. ПЛАНИРОВЩИК
# =================================================
def setup_scheduler_jobs():
    """Добавляет задачи планировщика (ежедневный и тестовый отчёт)."""
    # 🕕 Отчёт каждый день в 06:00 по Ташкенту
    scheduler.add_job(
        lambda: safe_async_task(send_daily_report_06()),
        CronTrigger(hour=6, minute=0, timezone="Asia/Tashkent"),
        id="daily_report",
        replace_existing=True
    )


    print("📅 Список задач планировщика:")
    for job in scheduler.get_jobs():
        # APScheduler 4.0 compatibility: .next_run_time может быть None или скрыт
        next_run = getattr(job, "next_run_time", None)
        if not next_run and hasattr(job, "trigger"):
            try:
                next_run = job.trigger.get_next_fire_time(None, datetime.now(pytz.timezone("Asia/Tashkent")))
            except Exception:
                next_run = "⏳ не определено"
        print(f"  • {job.id} → {next_run}")

# =================================================
# 🚀 4. ЗАПУСК БОТА
# =================================================
async def main():
    global MAIN_LOOP
    MAIN_LOOP = asyncio.get_running_loop()  # сохраняем ссылку на event loop

    print("🟢 Инициализация StartCheck Newton...")

    setup_scheduler_jobs()  # ⚡ добавляем задачи перед стартом
    if not scheduler.running:
        scheduler.start()
        print("✅ Планировщик запущен")

    await dp.start_polling(bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        print("🚫 Bot stopped.")
